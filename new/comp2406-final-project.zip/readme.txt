Student Name and ID: Aria Wong 101300465

Affidavit:
"I attest that I am the sole author of this submitted work and any code borrowed from other sources has been identified by comments placed in my submitted code.
Aria Wong, 101300465"

Install Instructions:
npm install

Launch Instructions
node server.js

Testing Instructions
http://localhost:3000/register
http://localhost:3000/
